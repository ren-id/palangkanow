---
title: "Kontak Palangka Now"
description: "Hubungi Palangka Now melalui kontak yang tersedia di halaman ini."
---
# Hubungi Palangka Now

[Unduh file kontak]({{ site.url }}/files/card.vcf), atau pindai QR code berikut untuk menyimpan kontak.

![Kartu Nama]({{ site.url }}/files/card.png)

Mengapa ditampilkan dalam gambar? Bot berbahaya menjelajah web untuk mencari alamat email yang ditampilkan dalam teks biasa untuk dikirimi spam.
