---
title: "Kebijakan Privasi Palangka Now"
description: "Kebijakan Privasi Palangka Now menerangkan tentang bagaimana situs dan aplikasi berinteraksi dengan pengguna."
---
# Kebijakan Privasi Palangka Now

* 
{:toc}

Kebijakan dibuat sesederhana mungkin.

## 1. Pengumpulan Data

Situs dan aplikasi tidak mengumpulkan data apa pun dari pengunjung.

**Pihak Ketiga** seperti **live chat** dan **plugin komentar** mungkin mengumpulkan data pribadi Anda. Dalam hal ini, silakan merujuk pada **Syarat dan Ketentuan Penggunaan** di situs **Pihak Ketiga** tersebut.

## 2. Akses Perangkat

Situs dan aplikasi dapat berfungsi tanpa izin khusus.

Karena situs dan aplikasi tidak mengumpulkan data dan memerlukan akses perangkat apa pun, kebijakan privasi ini tidak perlu panjang lebar.
