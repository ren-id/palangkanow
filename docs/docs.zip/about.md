---
title: "Tentang Palangka Now"
description: "Palangka Now (kadangkala 'palangkanow') adalah blog publik warga Palangka Raya. Semua warga boleh berpartisipasi menulis apa pun yang kekinian tentang Palangka Raya."
image: https://www.palangkanow.com/files/background.png
---
# Tentang

Palangka Now (kadangkala 'palangkanow') adalah blog publik warga Palangka Raya. 

Semua warga boleh berpartisipasi menulis apa pun yang kekinian tentang Palangka Raya.

Mau bicara? Tolong kunjungi halaman [Kontak]({{ site.url }}/contact).
